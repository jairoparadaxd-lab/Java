class Figura {
    protected String color;

    public Figura(String color) {
        this.color = color;
    }

    public double calcularArea() {
        return 0; // Sera sobrescrito por las hijas
    }

    public String getColor() {
        return color;
    }

    // Reto extra: muestra el color y el area
    public void describir() {
        System.out.println("Color: " + color + " - Area: " + String.format("%.2f", calcularArea()));
    }
}

class Circulo extends Figura {
    private double radio;

    public Circulo(String color, double radio) {
        super(color);
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * radio * radio;
    }
}

class Rectangulo extends Figura {
    private double ancho;
    private double alto;

    public Rectangulo(String color, double ancho, double alto) {
        super(color);
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public double calcularArea() {
        return ancho * alto;
    }
}

class Triangulo extends Figura {
    private double base;
    private double altura;

    public Triangulo(String color, double base, double altura) {
        super(color);
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }
}

public class MainFiguras {
    public static void main(String[] args) {
        Circulo c = new Circulo("Rojo", 5);
        Rectangulo r = new Rectangulo("Azul", 4, 6);
        Triangulo t = new Triangulo("Verde", 8, 3);

        System.out.println("Circulo");
        c.describir();
        System.out.println("---");
        System.out.println("Rectangulo");
        r.describir();
        System.out.println("---");
        System.out.println("Triangulo");
        t.describir();
    }
}
